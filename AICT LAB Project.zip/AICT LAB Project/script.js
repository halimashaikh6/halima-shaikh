// Mobile menu toggle
const toggler = document.getElementById('toggler');
const nav = document.querySelector('nav ul');

toggler.addEventListener('change', () => {
    if (toggler.checked) {
        nav.style.display = 'flex';
        nav.style.flexDirection = 'column';
        nav.style.position = 'absolute';
        nav.style.top = '100%';
        nav.style.left = '0';
        nav.style.width = '100%';
        nav.style.background = '#fff';
        nav.style.boxShadow = '0 5px 15px rgba(0,0,0,0.1)';
    } else {
        nav.style.display = 'none';
    }
});

// Initialize cart from localStorage
let cart = JSON.parse(localStorage.getItem('cart')) || [];
updateCartCounter();

// Add to cart functionality
document.querySelectorAll('.cart-btn').forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        const productBox = button.closest('.box');
        const productName = productBox.querySelector('h3').textContent;
        const productPrice = productBox.querySelector('.price').textContent.split(' ')[1]; // Get discounted price

        // Add to cart array
        cart.push({ name: productName, price: productPrice });
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCounter();
        alert(`${productName} added to cart!`);
    });
});

// Update cart counter
function updateCartCounter() {
    const cartIcon = document.getElementById('cart-icon');
    const count = cart.length;
    if (count > 0) {
        cartIcon.innerHTML = `<i class="fas fa-shopping-cart"></i> (${count})`;
    } else {
        cartIcon.innerHTML = '<i class="fas fa-shopping-cart"></i>';
    }
}

// Heart/favorite toggle
document.querySelectorAll('.fas.fa-heart').forEach(heart => {
    // Load favorite state from localStorage
    const productName = heart.closest('.box').querySelector('h3').textContent;
    const favorites = JSON.parse(localStorage.getItem('favorites')) || [];
    if (favorites.includes(productName)) {
        heart.style.color = '#ff6b6b';
    }

    heart.addEventListener('click', (e) => {
        e.preventDefault();
        const productName = heart.closest('.box').querySelector('h3').textContent;
        let favorites = JSON.parse(localStorage.getItem('favorites')) || [];

        if (favorites.includes(productName)) {
            // Remove from favorites
            favorites = favorites.filter(item => item !== productName);
            heart.style.color = '#333';
            alert(`${productName} removed from favorites.`);
        } else {
            // Add to favorites
            favorites.push(productName);
            heart.style.color = '#ff6b6b';
            alert(`${productName} added to favorites!`);
        }
        localStorage.setItem('favorites', JSON.stringify(favorites));
    });
});

// Contact form submission
const contactForm = document.getElementById('contact-form');
contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = contactForm.querySelector('input[type="text"]').value;
    const email = contactForm.querySelector('input[type="email"]').value;
    const number = contactForm.querySelector('input[type="number"]').value;
    const message = contactForm.querySelector('textarea').value;

    // Simulate form submission (in a real app, send to server)
    alert(`Thank you, ${name}! Your message has been sent. We'll get back to you at ${email} or ${number}.`);
    
    // Clear form
    contactForm.reset();
});

// Smooth scrolling for navbar links
document.querySelectorAll('nav ul li a').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href').substring(1);
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
            window.scrollTo({
                top: targetSection.offsetTop - 80, // Adjust for fixed header
                behavior: 'smooth'
            });
        }
        // Close mobile menu after click
        toggler.checked = false;
        nav.style.display = 'none';
    });
});

// Responsive adjustments
window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        nav.style.display = 'flex';
        nav.style.flexDirection = 'row';
        nav.style.position = 'static';
        nav.style.width = 'auto';
        nav.style.background = 'transparent';
        nav.style.boxShadow = 'none';
    } else {
        nav.style.display = 'none';
    }
});